# Side Menu

The Side Menu is a multi-level navigation control that is used on the left side of a web page.  It is used with "sticky" behavior.  It the entire menu fits within the view port, its position remains fixed as the user scrolls.  If the menu is longer that the view port, then as the user scrolls the menu adjusts so that users are able to access the entire menu. The Side Menu is used to either navigate a single page via jump links, or across multiple separate pages of closely related content. 
