# Guidance

- The design documentation accommodates up to three levels (even though the Angular 2 implementation has no restrictions on the number of levels).  Designers and developers are to constrain their designs to a maximum of three, and preferable two levels.
- Create fewer, longer pages the user can easily scroll through (think of mobile scrolling behavior).  The side menu is used to navigate from one anchor to another on these longer pages.  This is preferable to lots of short pages that require lots of clicking to navigate.
- Menu items at the lowest level reference anchors (see wire frames below).  For example, on a 1 level menu all menu items reference anchors.  On a two level menu, the first level references pages and the second level references anchors on those pages.

# Design

- Each level is visually distinct from other levels in the menu - using different indents, borders, hover behavior, etc
- The menu is used for navigation and always has a selected menu item
- The menu has visual hover and selection behaviors
- In multi-level menus, when a parent menu item is selected (only) its immediate children are visible

## Variations
There are three visual variations in the side menu, which are selected based on the type of functionality they support.

- **Display:** Style used for general content display pages
- **Data Entry:** Style used for data entry, where the appearance and icons present in the Side Menu indicate progress to user
- **Workspace:** Style used within the authenticated workspace to enable the user to navigate among related pages
