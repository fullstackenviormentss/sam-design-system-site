# Breadcrumbs

Breadcrumbs provide navigational context to where the user is currently in the site. (They do not dynamically display the prior pages visited.)
