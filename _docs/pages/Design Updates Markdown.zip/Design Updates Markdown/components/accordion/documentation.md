# Accordion

Accordions are a list of headers that can be clicked to hide or reveal additional content. The accordion is used across SAM to provide additional or secondary content, allowing users to quickly move through a page and expand only that content which interests them.
