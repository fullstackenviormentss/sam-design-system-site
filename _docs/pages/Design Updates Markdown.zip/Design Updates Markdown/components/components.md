
# Forms and Controls

Forms and controls that are common components ensure the SAM.gov front end is consistent and efficient to build and restyle. Using common controls, styles, and directives is the most robust approach for achieve this.


##Filters

## Search Input
**Small Search**<br>
The small search spans 4 columns or less. It does not include hint text. The Search button is simply an icon in place of the word 'Search'.

**Large Search**<br>
The large search spans more than 5 columns. It may include hint text. Search button text is the word 'Search'.

## Selectors
Select elements allow users to pick one (or more) items from a list of options.

- Agency Selector
- City/State/Congressional District/Country Selectors
- Grouped Selectors
- NAICS Code
- People
- PSC
- Single select
- Multi-select
- Checkbox
- Radio button

### Single Select
**Dropdown**<br>
A dropdown allows users to select one option from a list.

*When to use*
- There are two or more choices
- Character length of the choices are long but space is tight

**Radio Button**<br>
A radio button allows users to select from one of two choices.

*When to use*
- There are only two choices
- Both choices should be visible to the user

**Stand-alone Checkbox**<br>
A stand-alone checkbox allows users to toggle from one of two choices.

*When to use*
- A stand-alone checkbox can be used when a user needs to choose “yes” or “no” on only one option. For example, to toggle a setting on or off.

### Multi-select
**Checkbox**<br>
Checkboxes allow users to select one or more options from a visible list.

**Multi-select Component**

**Advanced Multi-select Component (Agency Picker)**

## Text Input
Text inputs allow people to enter any combination of letters, numbers, or symbols of their choosing (unless otherwise restricted). Text input boxes can span single or multiple lines.

## Date Input

### Functional 'Add' button (optional)
Depending on role access and domain functionality, a functional button to add a new item to the list may be available.

### Filter (optional)
Filter controls are organized on the left-hand side based on priority or organized based on workflow (such as for Wage Determination).

### Section Search Bar
In the upper right is a Search field, which returns results specific to the current site section.

### Display count
The display count provides a count of displayed results and total results.

### Sort control
The sort control enables the user to adjust the order in which list items appear.

### Pagination
Pagination indicates which page of results a user is on and enables the user to traverse to additional pages.
