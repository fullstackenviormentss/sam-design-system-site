# Comments

The Comments component is a feature that provides a forum for conversation among users of SAM.gov.  
