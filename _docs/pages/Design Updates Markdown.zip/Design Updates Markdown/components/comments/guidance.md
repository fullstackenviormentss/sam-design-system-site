# Guidance

The Comments component can be used in the following ways:

- When an open text field is needed to capture unique data not answered in other questions & could require further conversation
- In areas that benefit from gathering user feedback
- In areas where conversation between multiple users is helpful or necessary to capture
- Other examples may exist

This component should be used only when more limited question types are not useful. We can implement an arbitrary character limit on this component of 10,000 so as to optimize performance of the site while still allowing ample space for users to comment. While there are no limits to the amount of columns this component can take up on the grid, it is generally recommended that the comment box aligns with other form or result elements on the screen.

## Design

### Constraints

This display of comments should be hidden beneath an accordion menu, unless there is a business case for always displaying the comments. We are currently displaying the user ID rather than the name in order to save time on page load from individual API calls for each name.

### Assumptions

We are assuming this section is used only on pages available to authenticated users. A user must be signed in to leave a comment - otherwise, this option should be hidden.
