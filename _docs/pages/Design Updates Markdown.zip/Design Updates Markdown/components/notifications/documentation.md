# Notifications

Notifications are SAM's way of communicating various types of information with users. They can either let the user know that an action is required, or be simply informational. Notifications is a global feature from the header that aggregates personalized messages that are likely to be important to a specific user. Personalized means the messages sent to a user are based on a user’s roles and preferences.
