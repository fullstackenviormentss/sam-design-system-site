## Guidance

Only authenticated users will see notifications in the top banner and in their My Feed

### Notification types

**Requests:**things you take action on (access, title requests, task-based)
- Frequently requires the user to take action
- Typically based on a stateful workflow

**Announcements:**policy changes, API or data changes coming up
- May describe something coming up soon or something that may not take place for 18 months, such as a system api change.

**Notifications:**your watch lists (wage determinations, opportunities), scheduled reports have failed/succeeded, password needs to be updated soon, etc
- Typically notify users that something has changed
- Typically specific to a user
- Frequently leads to an action or to viewing of new information


## Design
- User clicks the notification icon in the banner and see the top 3 or 5 individual notification (not a “roll-up” or summary)
- Notifications appear in real time
- Once user clicks a notification in the banner list, he/she is brought to the page where that task/request/item lives (not the Workspace or My Feed)

Highlight/shade lines of notifications that haven’t been clicked on so that people won't miss individual items in the banner.
- When a new notification arrives, it is indicated by an updated count in a badge next to the notifications icon.
- Notifications are ordered according to the time they are received, with most recent at the top.
- 10 (?) of the most recent notifications appear in the view of the notifications list. A link below the notifications takes the user to a page with the full feed of all notifications.
- An individual notification should link to the relevant page on the website.
- A level 2 notifications feed page will have all notifications listed (across domains) and can be sorted/filtered
- A level 2 domain page may have a banner that lists a count, such as ‘You have 4 new notifications’
