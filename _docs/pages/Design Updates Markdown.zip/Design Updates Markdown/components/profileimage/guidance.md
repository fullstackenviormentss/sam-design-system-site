# Guidance

Any displayed object may have a profile image.  An object has only one profile image.

# Design

- The display dimensions for a profile image are 160 pixels by 160 pixels.
- The image dimensions should be at a minimum 160 pixels by 160 pixels.  The recommended and maximum image dimensions are 320 pixels by 320 pixels.
- For best display results, images should be square.  Images will be fit into the image space (160 x 160) with no stretching.
