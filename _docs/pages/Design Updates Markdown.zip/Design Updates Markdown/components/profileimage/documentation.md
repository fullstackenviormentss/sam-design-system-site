# Profile Image

A profile image represents the identity of an organization, a person, a program, or other object.
