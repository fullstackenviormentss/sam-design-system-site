
# Guidance

The Workspace Level 2 page layout is used to display to the authenticated user a listing of related items, generally requiring the user's action, or for which the user has responsibility.

# Design Criteria

- The page may have a side menu (workspace style) when there are multiple related workspace subject pages in a domain
- When relevant, action buttons are available
- When relevant, a button to create a new object (such as Assistance Listing) is available
- The page has controls enabling the user to filter or sort items on the list
- The page has no need to be broken into distinct sections due to its length or complexity
- Pagination is present on the page where list of items exceeds 20 items

## List Item Elements

Workspace Level 2 Items can display a variety of data depending on business needs. Following are the most common data elements that allow the user to easily identify and act on a list item.

- Item Name
- Item Description
- Status
- Action Buttons (e.g., Edit, Delete, Archive)
- Dates (e.g., Published, Due, Modified)
