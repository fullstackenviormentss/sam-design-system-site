
# Workspace Level 2 Page

The workspace Level 2 page is available to an authenticated user and is individualized, based on a user's organization, roles, and preferences. The workspace Level 2 is where users go to view a specific domain-level page with functions for which they have view, edit, or administrative capabilities.
