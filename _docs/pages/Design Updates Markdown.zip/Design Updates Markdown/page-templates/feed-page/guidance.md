
# Guidance

Only authenticated users will see notifications in the top banner and in their My Feed. My Feed is a chronological listing of notifications specific to each user. It's accessible from the Workspace or by clicking "See All" on the notifications banner.

Items that appear in My Feed are driven by
- Roles
- The organization a user belongs to
- What a user has signed up for (what wage determinations or opportunities a user is watching, for example)

# Design Criteria

- Notifications in the feed should be simple, one-liners and not huge descriptions/information
- There are different types of notifications, but they should all go in the same feed.
- Can have a notification that doesn't necessarily require action.
- The page has controls enabling the user to filter or sort items on the list
- The page has no need to be broken into distinct sections due to its length or complexity
- Feed items link directly to the object to which they refer (e.g., a feed item for a status change on a role request links directly to the role request, not to a higher level workspace page of all role requests)

## List Item Elements

Feed Items can display a variety of data depending on business needs. Following are the most common data elements that allow the user to easily identify and act on a feed item.

- Item Name
- Item Description
- Status
- Dates (e.g., Published, Due, Modified)
