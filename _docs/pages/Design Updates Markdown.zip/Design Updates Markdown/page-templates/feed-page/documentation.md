
# Feed Page

The Feed page layout is used to display a listing of short, related items, with limited functionality.
