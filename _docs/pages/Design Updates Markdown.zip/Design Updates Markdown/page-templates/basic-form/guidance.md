
# Guidance

The Basic Form generally would not scroll vertically or have a sidemenu.

# Design Criteria

A basic form page has the following characteristics.

- The page has a form where the user enters and submits information
- The user typically enters all information quickly (< 5 min) with little preparation
- The form has few or no conditional statements that affect what information the user must provide
- The form has no need to be broken into distinct sections due to its length or complexity
- The form does not need a sidemenu
- The form has few or no fields that require a complex editor
