
# Basic Form

The Basic Form layout is used when the user is presented with a basic form containing a limited number of form fields and functionality, such as a log in page.
