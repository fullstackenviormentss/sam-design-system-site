
# Guidance

The Landing Page is used for the header menu-level pages: Home, Workspace, Reports, Help, Federal Hierarchy, Data Services.

# Design Criteria

A landing page has the following characteristics.

- The page has a large photograph/image that thematically refers to the content contained in the subpages
- The landing page should provide a summary information about available content and functions
- The landing page should provide links to frequently accessed, priority content and functions
- Landing pages may have different states or availability depending on if user is logged in or has role privileges
