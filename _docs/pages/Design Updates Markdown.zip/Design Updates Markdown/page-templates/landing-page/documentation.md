
# Landing Page

The Landing Page layout provides a quick visual overview of subcontent and quick access to key content and functions on subpages.
