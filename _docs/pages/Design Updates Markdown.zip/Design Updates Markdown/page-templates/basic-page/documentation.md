
# Basic Page

The Basic page layout is used when the user is presented with basic page containing mostly text, some images, and limited interactivity.
