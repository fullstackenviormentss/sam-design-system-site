
# Guidance

The Basic Page has few or limited interactive elements. Interactive elements on a basic page generally perform simple actions, such as sort/organize content, or minimize/maximize the visible content.

A basic page may scroll vertically; subnavigation can be used to jump to sections on a scrolling page.

![Basic Page Layout](/images/BasicLayout2.png)

# Design Criteria

- The Level 1 category (Home, Workspace, Help, Hierarchy, Data Services) or Domain (e.g., Federal Assistance Listing, Opportunity, Entity) is listed above the page title.
- Each page is titled with clear and concise text describing the content of the page.
- The Basic page does not have a sidemenu.
- The page may scroll vertically to a minimum degree, otherwise consider the display page format with sections and sidemenu.
