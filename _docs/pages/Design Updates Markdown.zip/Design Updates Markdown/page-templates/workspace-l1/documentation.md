
# Workspace Level 1 Page

The workspace landing page (Tier 1 "My Workspace") is available to an authenticated user. The workspace Level 1 is where users go to view all the pages and functions for which they have view, edit, or administrative capabilities. Subpages (Tier 2) are individualized, based on a user's organization, roles, and preferences.
