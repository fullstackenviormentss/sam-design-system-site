
# Guidance

The Data Entry page provides the authenticated user functions for which they have view, edit, or administrative capabilities.

# Design Criteria

A complex data entry page has the following characteristics.

- The page has a form where the user enters and submits information
- The user typically enters information in multiple sessions (> 30 min). The user may need to save as a draft to gather further information, or there may be workflow steps involving multiple users.
- The form has multiple conditional statements that affect what information the user must provide
- The form has multiple fields that require a complex editor
- The form should be broken into distinct sections due to its length or complexity
- Distinct sections are represented by the sidemenu (data entry style) that visually displays status of form completion
- When appropriate, tabs on the Data Entry page enable the user to toggle between edit, authenticated view, and public view modes to compare form content

## Toolbar

The toolbar on a complex data entry page may have a toolbar with the following possible functions.

- Cancel
- Next (optional)
- Previous (optional)
- Done
- Show Errors (optional)
