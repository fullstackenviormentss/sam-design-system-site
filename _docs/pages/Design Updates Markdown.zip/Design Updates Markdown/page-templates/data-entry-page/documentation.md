
# Data Entry Page

The Data Entry Page is used or complex forms that require multiple pages and interactions.
