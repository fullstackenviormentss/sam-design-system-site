
# Guidance

The Display Page has few or limited interactive elements. Interactive elements on a display page generally perform simple actions, such as sort/organize content, or minimize/maximize the visible content.

# Design Criteria

- A display page with lengthy content should have summary information at the top
- A display page may scroll vertically
- The page may have a side menu (display style)
- Large amounts of content should be broken up into sections
- The sidemenu is used to jump to sections; the page will respond by moving up or down to focus on the selected section
- When relevant, action buttons are available to authenticated users
- Graphics, such as a profile image, or tables and charts may be present
- Interactive elements on a display page include history or timelines
