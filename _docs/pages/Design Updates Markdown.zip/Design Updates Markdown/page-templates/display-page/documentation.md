
# Display Page

The Display Page is used as a standard layout to display domain content.
