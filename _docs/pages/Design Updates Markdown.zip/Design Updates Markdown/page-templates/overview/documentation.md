
# Page Templates

The majority of pages on SAM.gov should follow the following page templates to ensure the site has a consistent look and user experience.

For each page, a Balsamiq template and a code template are available from [Downloads](/page/page)

| Layout  | Template Name | Description |
|:-------------:|:-------------:|:-------------:|
|![Landing Page](/images/landing-page.png)| Landing Page | <p align="left">Layout provides access to key content and functions of related subpages.
|![Basic Page](/images/basic-page.png)| Basic Page | <p align="left">Simple content, typically static text such as on a help page.
|![Basic Form](/images/basic-form.png)| Basic Form | <p align="left">Simple form, such as log in.
|![Display Page](/images/display-page.png)| Display Page | <p align="left">Standard layout to display domain content.
|![Feed Page](/images/feed-page.png)| Feed Page | <p align="left">Listing of short, related items, with limited functionality.
|![Workspace Level 1 Page](/images/workspace-t1.png)| Workspace Level 1 Page | <p align="left">The workspace Tier 1 page displays what an authenticated user has access to work with.
|![Workspace Level 2 Page](/images/workspace-t2.png)| Workspace Level 2 Page | <p align="left">Listing of related items, with filters and complex interactions.
|![Data Entry Page](/images/complex-data-entry.png)| Data Entry Page | <p align="left">Complex forms, requiring multiple pages and interactions.
