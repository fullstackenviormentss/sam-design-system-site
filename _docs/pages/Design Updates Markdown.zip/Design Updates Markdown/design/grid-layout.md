
# Grid Layout

SAM.gov is designed against a 12-column responsive grid layout based on a 1024 x 768 view to accommodate users with older displays, as well as scale elegantly for mobile devices.

![Desktop](/images/Desktop.png)

Refer to the U.S. Web Design Standards section on [Grids.](https://standards.usa.gov/components/grids/)
