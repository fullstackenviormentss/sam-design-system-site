# Inline Messaging

## Description
Our site employs the use of a variety of alerts and message banners. This design document lays out our definitions and uses of the following types of alerts and message banners so that they are used consistently throughout the site:

| | Broadcast alert | Display Page Alert | Data Entry alert | Modal Alert |
| -------------------------------------------------------------------- |:-------------:| ------- |:-------------|
| **Reference** | ![broadcast alert](/images/.png) | ![display page alert](/images/.png)| ![data entry alert](/images/.png) |![Modal Alert](/images/modal.png) |
| **When to use**	| Dismissible information needs to be relayed site-wide, regardless of authentication |	Fixed information applies solely to a single page view | Interactive information is related solely to the completion of a data entry form	| Transient message at the page level |
| **Action** | Appears by default but can be dismissed for remainder of browser session by clicking icon. Link may navigate user to more content.  | Static text | Expands or collapses view of additional content when clicking link or icon  | Appears then disappears after 20 seconds |
| **Effect on page layout** |	Pushes page content down | Pushes page content down |	Pushes page content down or up |	Overlaid on top of existing content (content is not shifted) |
| **SAM.gov Example** |	System maintenance alert	| Information alert at top of Opportunity | Error Warning at top of Data Entry page	| Success message |
