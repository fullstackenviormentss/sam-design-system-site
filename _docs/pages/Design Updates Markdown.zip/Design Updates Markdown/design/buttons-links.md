# Buttons and Links

## Guidance
- Use buttons to signal important actions available to the user.

- Use links for navigation.   
- **Internal Links:** Internal links navigate the user within the site by replacing one view with the next within the same browser window.
- **External Links:** Links that take the user away from the SAM.gov site should have the _icon image here_ (fa-external-link) after the text. The external page should open in a new browser window.

The SAM.gov site follows the standards outlined on the [U.S. Web Design Standards Buttons page](https://standards.usa.gov/components/buttons/).

## Description
Our site employs the use of a variety of buttons and button styles. This design document lays out our definitions and uses of the following types of buttons and button styles so that they are used consistently throughout the site:

| | Primary | Secondary | Tertiary | Action | Action dropdown |
| -------------------------------------------------------------------- |:-------------:| ------- |:-------------|
| **Reference** | ![primary](/images/primary.png) | ![secondary](/images/secondary.png) ![search](/images/search.png) |![Tertiary](/images/tertiary.png) | ![action](/images/action.png)| ![action dropdown](/images/actions-dd.png)|
| **When to use**	| Use the darker, primary color set for the most important buttons the users will look for in order to initiate an activity (e.g., Create Listing) or complete an activity (e.g., Submit). |	Use the secondary color set for the buttons of secondary importance. Examples include search or form-related actions, such as adding data to a table or adding terms in the Advanced section of the Agency Picker. | Tertiary buttons represent useful, but not necessary actions the user may want to take, such as navigating from the page (Cancel).	| Action buttons should be used for page-level features (e.g., download, subscribe) Action buttons can also be used for object-level functions, such as Edit or Delete.  | The Action dropdown is used where two or more closely related functions on an object or page are available. |
| **Guidance** |	Typically no more than one button in this color should appear on the page, although there may be occasions to modify this rule. Primary buttons generally appear at the top of a page when the action is to initiate work, or at the bottom of the form, such as when the action is to submit that form. May appear in a disabled state until form requirements are met. | Search-related buttons should be css 'color-primary-alt' (#02bfe7) for consistency. | Generally, tertiary buttons are paired with secondary and primary buttons, but represent the least important action, such as navigating from a form.  | Pair these Action buttons with the appropriate icon. Page-level action buttons generally appear at the very top of the page. | 	Action dropdown buttons are typically at the object level, but may appear at the page level. |
