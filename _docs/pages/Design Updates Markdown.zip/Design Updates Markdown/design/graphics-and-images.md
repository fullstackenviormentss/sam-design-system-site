# Images and Graphics

## Photography

Photography is used on the Home Landing Page and Section-Level Landing Pages. When selecting photographs, choose images that embody the SAM.gov tagline "SAM.gov is the official U.S. government website for people who make, receive, and manage federal awards."  

Photographs should include the following attributes:
- One or more people of diverse attributes with positive facial expressions
- Engaged in activities related to U.S. Government grants or contracts

## Graphics
